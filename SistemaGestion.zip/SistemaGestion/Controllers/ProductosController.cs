﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SistemaGestion.Data;
using SistemaGestion.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaGestion.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ProductosController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Producto>>> GetProductos()
        {
            try
            {
                var productos = await _context.Productos.ToListAsync();

                // Verificar si hay valores nulos y manejarlos
                foreach (var producto in productos)
                {
                    if (producto.Descripcion == null)
                        producto.Descripcion = "Descripción no disponible";
                    if (producto.Costo == 0)
                        producto.Costo = 0.01m; // Valor por defecto para evitar errores
                    if (producto.PrecioVenta == 0)
                        producto.PrecioVenta = 0.01m; // Valor por defecto para evitar errores
                    if (producto.Stock == 0)
                        producto.Stock = 1; // Valor por defecto para evitar errores
                    if (producto.Categoria == null)
                        producto.Categoria = "Categoría no disponible";
                }

                return productos;
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = $"Internal server error: {ex.Message}" });
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Producto>> GetProducto(int id)
        {
            var producto = await _context.Productos.FindAsync(id);
            if (producto == null)
            {
                return NotFound(new { message = "Producto no encontrado" });
            }
            return producto;
        }

        [HttpPost]
        public async Task<ActionResult<Producto>> CrearProducto(Producto nuevoProducto)
        {
            _context.Productos.Add(nuevoProducto);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetProducto), new { id = nuevoProducto.Id }, nuevoProducto);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> ModificarProducto(int id, Producto productoActualizado)
        {
            if (id != productoActualizado.Id)
            {
                return BadRequest(new { message = "ID no coincide" });
            }
            _context.Entry(productoActualizado).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductoExists(id))
                {
                    return NotFound(new { message = "Producto no encontrado" });
                }
                else
                {
                    throw;
                }
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarProducto(int id)
        {
            var producto = await _context.Productos.FindAsync(id);
            if (producto == null)
            {
                return NotFound(new { message = "Producto no encontrado" });
            }
            _context.Productos.Remove(producto);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private bool ProductoExists(int id)
        {
            return _context.Productos.Any(e => e.Id == id);
        }
    }
}
