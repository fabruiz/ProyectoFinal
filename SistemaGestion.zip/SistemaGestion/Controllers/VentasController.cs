﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SistemaGestion.Data;
using SistemaGestion.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaGestion.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VentasController : ControllerBase
    {
        private readonly AppDbContext _context;

        public VentasController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Venta>>> GetVentas()
        {
            try
            {
                var ventas = await _context.Ventas.ToListAsync();
                return Ok(ventas);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpPost]
        public async Task<IActionResult> RegistrarVenta([FromBody] VentaDTO ventaDTO)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();

            try
            {
                // Crear una nueva venta
                var venta = new Venta
                {
                    Fecha = DateTime.Now,
                    UsuarioId = ventaDTO.UsuarioId,
                    ProductosVendidos = new List<ProductoVendido>()
                };

                _context.Ventas.Add(venta);
                await _context.SaveChangesAsync();

                // Añadir productos vendidos y actualizar el stock
                foreach (var productoVendidoDTO in ventaDTO.ProductosVendidos)
                {
                    var productoVendido = new ProductoVendido
                    {
                        VentaId = venta.Id,
                        ProductoId = productoVendidoDTO.ProductoId,
                        Cantidad = productoVendidoDTO.Cantidad,
                        PrecioVenta = productoVendidoDTO.PrecioVenta
                    };

                    _context.ProductosVendidos.Add(productoVendido);

                    var producto = await _context.Productos.FindAsync(productoVendidoDTO.ProductoId);
                    if (producto == null || producto.Stock < productoVendidoDTO.Cantidad)
                    {
                        return BadRequest($"Stock insuficiente para el producto con ID: {productoVendidoDTO.ProductoId}");
                    }
                    producto.Stock -= productoVendidoDTO.Cantidad;
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                return Ok(venta);
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        public class VentaDTO
        {
            public int UsuarioId { get; set; }
            public List<ProductoVendidoDTO> ProductosVendidos { get; set; }
        }

        public class ProductoVendidoDTO
        {
            public int ProductoId { get; set; }
            public int Cantidad { get; set; }
            public decimal PrecioVenta { get; set; }
        }
    }

}