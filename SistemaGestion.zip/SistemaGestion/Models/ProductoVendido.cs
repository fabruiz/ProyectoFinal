﻿using SistemaGestion.Models;

namespace SistemaGestion.Models
{
    public class ProductoVendido
    {
        public int Id { get; set; }
        public int VentaId { get; set; }
        public int ProductoId { get; set; }
        public int Cantidad { get; set; }
        public decimal PrecioVenta { get; set; }
        public Venta Venta { get; set; }
        public Producto Producto { get; set; }
    }
}
