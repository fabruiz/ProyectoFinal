﻿using SistemaGestion.Models;

namespace SistemaGestion.Models
{
    public class Venta
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }
        public int UsuarioId { get; set; }
        public List<ProductoVendido> ProductosVendidos { get; set; }
    }
}
