﻿namespace SistemaGestion.Models
{
    public class Persona
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Contraseña { get; set; } 

        public ICollection<Usuario> Usuarios { get; set; } 
    }
}
