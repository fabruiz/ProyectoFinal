﻿document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault(); 

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    console.log(`Attempting login with email: ${email} and password: ${password}`);

    fetch(`http://localhost:5072/api/usuarios/login?email=${email}&contraseña=${password}`, {
        method: 'GET'
    })
        .then(response => {
            console.log('Received response:', response);
            if (!response.ok) {
                throw new Error('Correo o contraseña incorrectos');
            }
            return response.text();
        })
        .then(data => {
            console.log('Received data:', data);
            document.getElementById('message').textContent = data;
            if (data === 'Inicio de sesión exitoso') {
                console.log('Redirigiendo a home.html');
                window.location.href = 'html/home.html'; 
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('message').textContent = error.message;
        });
});
