﻿document.addEventListener('DOMContentLoaded', function () {
    const ventaForm = document.getElementById('ventaForm');

    ventaForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const usuarioId = document.getElementById('usuarioId').value;
        const productoId1 = document.getElementById('productoId1').value;
        const cantidad1 = document.getElementById('cantidad1').value;
        const precioVenta1 = document.getElementById('precioVenta1').value;

        // Crear la lista de productos vendidos
        const productosVendidos = [
            {
                ProductoId: productoId1,
                Cantidad: cantidad1,
                PrecioVenta: precioVenta1
            }
        ];

        // Realizar la solicitud POST para registrar la venta
        fetch('http://localhost:5072/api/ventas', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                UsuarioId: usuarioId,
                ProductosVendidos: productosVendidos
            })
        }).then(response => {
            if (!response.ok) {
                return response.json().then(error => { throw new Error(error.message); });
            }
            return response.json();
        }).then(data => {
            alert('Venta registrada con éxito');
            ventaForm.reset();
        }).catch(error => {
            console.error('Error registrando la venta:', error);
            alert('Error registrando la venta: ' + error.message);
        });
    });
});
