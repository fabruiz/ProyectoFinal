﻿document.getElementById('registerForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Previene el comportamiento predeterminado del formulario

    const personaNombre = document.getElementById('personaNombre').value;
    const fechaNacimiento = document.getElementById('fechaNacimiento').value;
    const contraseña = document.getElementById('contraseña').value;
    const usuarioNombre = document.getElementById('usuarioNombre').value;
    const email = document.getElementById('email').value;

    // Crear Persona
    fetch('http://localhost:5072/api/personas', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            nombre: personaNombre,
            fechaNacimiento: fechaNacimiento,
            contraseña: contraseña
        })
    })
        .then(response => response.json())
        .then(persona => {
            // Crear Usuario asociado a la Persona
            return fetch('http://localhost:5072/api/usuarios', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    personaId: persona.id,
                    nombre: usuarioNombre,
                    email: email
                })
            });
        })
        .then(response => response.json())
        .then(data => {
            document.getElementById('message').textContent = 'Usuario registrado con éxito';
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('message').textContent = 'Error al registrar el usuario';
        });
});
