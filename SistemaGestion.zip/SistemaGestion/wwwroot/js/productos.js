﻿document.addEventListener('DOMContentLoaded', function () {
    const productTable = document.getElementById('productTableBody');
    const newProductButton = document.getElementById('newProductButton');
    const deleteProductButton = document.getElementById('deleteProductButton');
    const searchProductButton = document.getElementById('searchProductButton');
    const productFormContainer = document.getElementById('productFormContainer');
    const deleteFormContainer = document.getElementById('deleteFormContainer');
    const searchFormContainer = document.getElementById('searchFormContainer');
    const productForm = document.getElementById('productForm');
    const deleteForm = document.getElementById('deleteForm');
    const searchForm = document.getElementById('searchForm');

    // Función para mostrar productos
    function fetchProducts() {
        fetch('http://localhost:5072/api/productos')
            .then(response => {
                if (!response.ok) {
                    return response.json().then(error => { throw new Error(error.message); });
                }
                return response.json();
            })
            .then(data => {
               // console.log('Fetched data:', data);
                const productos = data.$values; // Acceder al array dentro de $values
                if (!Array.isArray(productos)) {
                    throw new Error('Data is not an array');
                }
                productTable.innerHTML = '';
                productos.forEach(producto => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${producto.id}</td>
                        <td>${producto.descripcion}</td>
                        <td>${producto.costo}</td>
                        <td>${producto.precioVenta}</td>
                        <td>${producto.stock}</td>
                        <td>${producto.categoria}</td>
                    `;
                    productTable.appendChild(row);
                });
            })
            .catch(error => {
                console.error('Error fetching products:', error);
                productTable.innerHTML = `<tr><td colspan="6">Error: ${error.message}</td></tr>`;
            });
    }

    // Evento para mostrar el formulario de nuevo producto
    newProductButton.addEventListener('click', () => {
        productFormContainer.style.display = 'block';
        deleteFormContainer.style.display = 'none';
        searchFormContainer.style.display = 'none';
    });

    // Evento para mostrar el formulario de eliminar producto
    deleteProductButton.addEventListener('click', () => {
        deleteFormContainer.style.display = 'block';
        productFormContainer.style.display = 'none';
        searchFormContainer.style.display = 'none';
    });

    // Evento para mostrar el formulario de buscar producto
    searchProductButton.addEventListener('click', () => {
        searchFormContainer.style.display = 'block';
        productFormContainer.style.display = 'none';
        deleteFormContainer.style.display = 'none';
    });

    // Evento de enviar formulario para crear producto
    productForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const descripcion = document.getElementById('productDescription').value;
        const costo = document.getElementById('productCost').value;
        const precioVenta = document.getElementById('productPrice').value;
        const stock = document.getElementById('productStock').value;
        const categoria = document.getElementById('productCategory').value;

        fetch('http://localhost:5072/api/productos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                descripcion: descripcion,
                costo: costo,
                precioVenta: precioVenta,
                stock: stock,
                categoria: categoria
            })
        }).then(response => {
            if (!response.ok) {
                return response.json().then(error => { throw new Error(error.message); });
            }
            fetchProducts();
            productForm.reset();
            productFormContainer.style.display = 'none';
        }).catch(error => {
            console.error('Error creating product:', error);
        });
    });

    // Evento de enviar formulario para eliminar producto
    deleteForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const productId = document.getElementById('deleteProductId').value;

        fetch(`http://localhost:5072/api/productos/${productId}`, {
            method: 'DELETE'
        }).then(response => {
            if (!response.ok) {
                return response.json().then(error => { throw new Error(error.message); });
            }
            fetchProducts();
            deleteForm.reset();
            deleteFormContainer.style.display = 'none';
        }).catch(error => {
            console.error('Error deleting product:', error);
        });
    });

    // Evento de enviar formulario para buscar producto
    searchForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const productId = document.getElementById('searchProductId').value;

        fetch(`http://localhost:5072/api/productos/${productId}`)
            .then(response => {
                if (!response.ok) {
                    return response.json().then(error => { throw new Error(error.message); });
                }
                return response.json();
            })
            .then(producto => {
                productTable.innerHTML = `
                    <tr>
                        <td>${producto.id}</td>
                        <td>${producto.descripcion}</td>
                        <td>${producto.costo}</td>
                        <td>${producto.precioVenta}</td>
                        <td>${producto.stock}</td>
                        <td>${producto.categoria}</td>
                    </tr>
                `;
                searchFormContainer.style.display = 'none';
            })
            .catch(error => {
                console.error('Error searching product:', error);
                productTable.innerHTML = `<tr><td colspan="6">Error: ${error.message}</td></tr>`;
            });
    });

    // Obtener productos al cargar la página
    fetchProducts();
});
