﻿document.addEventListener('DOMContentLoaded', function () {
    const ventasTable = document.getElementById('ventasTableBody');

    // Función para mostrar ventas
    function fetchVentas() {
        fetch('http://localhost:5072/api/ventas')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log('Fetched data:', data);
                const ventas = data.$values;
                if (!Array.isArray(ventas)) {
                    throw new Error('Data is not an array');
                }
                ventasTable.innerHTML = '';
                ventas.forEach(venta => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${venta.id}</td>
                        <td>${new Date(venta.fecha).toLocaleString()}</td>
                        <td>${venta.usuarioId}</td>
                    `;
                    ventasTable.appendChild(row);
                });
            })
            .catch(error => {
                console.error('Error fetching ventas:', error);
                ventasTable.innerHTML = `<tr><td colspan="3">Error: ${error.message}</td></tr>`;
            });
    }

    // Obtener ventas al cargar la página
    fetchVentas();
});
